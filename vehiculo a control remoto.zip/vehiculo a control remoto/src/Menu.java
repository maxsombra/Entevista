import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Menu {

	private static Scanner entradaEscaner = new Scanner (System.in);
	grilla Grilla ;
	vehiculo car;
	
	public Menu() {
		
	}
	
	public void start() throws InterruptedException {
		@SuppressWarnings("deprecation")
		int horas = new Date().getHours();
		String saludo = "Buenos dias";
		if(horas > 12 && horas < 18) {
			saludo = "Buenas tardes";
		}else if(horas >= 18) {
			saludo = "Buenas noches";
		}
		System.out.println (saludo+", iniciando Sistema");
		
		Grilla = new grilla();
		car = new vehiculo();
		
		for ( int i = 0 ; i < 10 ; i++) {
			System.out.print(".");
			TimeUnit.SECONDS.sleep(1);
		}
		System.out.println("*"); 
		definirGrilla(Grilla);
		Menu(Grilla,car);
	}
	
	public static void definirGrilla(grilla Grilla) {
		boolean a = true;
		while(a) {
			System.out.println ("ingresa las dimenciones de la grilla en el formato <Fila>,<Columna>:");
			
			String dim = "";
			while(dim.equals("")) {
				dim = entradaEscaner.nextLine();
			}
			
			Pattern patron = Pattern.compile("^\\d+,\\d+$");
			Matcher encaja = patron.matcher(dim);
			if(encaja.matches()) {
				String[] parts = dim.split(",");
				Grilla.definicion(parts[0], parts[1]);
				a = false;
			}else {
				System.out.println("Error en formato de comando");
			}
		}
	}
 
	public static void Mover(grilla Grilla,vehiculo car) {
		System.out.println("      N     ");
		System.out.println("O <-    -> E");
		System.out.println("      S     ");
		System.out.println ("ingresa los comandos con el siguiete formato  <Desplazamiento>,<Direccion>;<Desplazamiento>,<Direccion> :");
		
		String dim = "";
		while(dim.equals("")) {
			dim = entradaEscaner.nextLine();
		}
		String[] parts = dim.split(";");
		
		for(int i = 0 ; i < parts.length ; i++) {
			String comando = parts[i];
			
			Pattern patron = Pattern.compile("^\\d+,[NSEO]$");
			Matcher encaja = patron.matcher(comando);
			System.out.println("Comando "+ comando); 
			if(encaja.matches()) {
				String[] part = comando.split(",");
				System.out.println(car.mover(part[0], part[1],Grilla));
			}else {
				System.out.println("Error en formato de comando");
			}
		}
		
		
	}
	
	public static void Menu(grilla Grilla,vehiculo car) {
		int op = 0;
		boolean reprint = true;
		while(op != 3) {
			if(reprint) {
				System.out.println("-------------------------\n");
				System.out.println("Selecciona una opcion");
		        System.out.println("-------------------------\n");
		        System.out.println("1 - Modificar el tama�o de la grilla");
		        System.out.println("2 - enviar comandos al carro");
		        System.out.println("3 - Salida");
			}else {
				reprint = true;
			}
	        op = entradaEscaner.nextInt();
	        switch (op) {
		        case 1:
		            // Modificar el tama�o de la grilla.
		        	definirGrilla(Grilla);
		            break;
		        case 2:
		            // enviar comandos al carro.
		        	Mover(Grilla,car);
		            break;
		        case 3:
		            // Salida.
		        	System.out.println("Hasta luego");
		            break;
		        default:
		        	System.out.println("opcion invalida, seleciona una valida");
		        	reprint = false;
		        	break;
		    }
	        
		}
	}
	
}
