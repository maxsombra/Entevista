
public class grilla {
	private int filas;
	private int columnas;
	
	public grilla() {
	}
	
	public void definicion(int filas , int columnas) {
		this.setFilas(filas);
		this.setColumnas(columnas);
	}
	
	public void definicion(String filas , String columnas) {
		this.setFilas(Integer.parseInt(filas)) ;
		this.setColumnas(Integer.parseInt(columnas)) ;
	}

	public int getFilas() {
		return filas;
	}

	public void setFilas(int filas) {
		this.filas = filas;
	}

	public int getColumnas() {
		return columnas;
	}

	public void setColumnas(int columnas) {
		this.columnas = columnas;
	}
}
