import java.io.IOException;

public class main {
	

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		Menu menu = new Menu();
		try {
			menu.start();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
