
public class vehiculo {
	private int fila;
	private int columna;
	private String UltimoMensaje;
	
	public vehiculo () {
		fila = 0;
		columna = 0;
		UltimoMensaje = "Auto en marcha";
	}
	
	public String mover(String desplazamiento, String direccion , grilla Grilla) {
		//			(Filas,Columna)			
		//      N
		//O <-    -> E
		//      S
		//(0,0)
		int desp = Integer.parseInt(desplazamiento);
		if  (direccion.equals("N") || direccion.equals("S")) {
			//filas
			int tama�o = Grilla.getFilas();
			if(direccion.equals("N")) {
				fila += desp;
				if(fila >= tama�o) {
					fila = tama�o-1;
					UltimoMensaje = "Se ha detenido el avance por salir de los limites, ";
				}else {
					UltimoMensaje = "";
				}
			}else {
				fila -= desp;
				if(fila < 0) {
					fila = 0;
					UltimoMensaje = "Se ha detenido el avance por salir de los limites, ";
				}else {
					UltimoMensaje = "";
				}
			}
		}else {
			//columna
			int tama�o = Grilla.getColumnas();
			if(direccion.equals("E")) {
				columna += desp;
				if(columna >= tama�o) {
					columna = tama�o-1;
					UltimoMensaje = "Se ha detenido el avance por salir de los limites, ";
				}else {
					UltimoMensaje = "";
				}
			}else {
				columna -= desp;
				if(columna < 0) {
					columna = 0;
					UltimoMensaje = "Se ha detenido el avance por salir de los limites, ";
				}else {
					UltimoMensaje = "";
				}
			}
		}
		return UltimoMensaje + " Posicion: ("+fila+","+columna+")";
	}
	
	
}
